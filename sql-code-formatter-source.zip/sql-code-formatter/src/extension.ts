import * as vscode from 'vscode';
import { loadStyle, getBundledStylePath, type SqlStyle } from './styleFile';
import { formatSql } from './formatter';

let output: vscode.OutputChannel;

function log(message: string): void {
  const debug = vscode.workspace.getConfiguration('sqlCodeFormatter').get<boolean>('debugLogging', false);
  if (debug) {
    output.appendLine(message);
  }
}

async function getActiveStyle(): Promise<SqlStyle> {
  const cfg = vscode.workspace.getConfiguration('sqlCodeFormatter');
  const styleFile = cfg.get<string>('styleFile', '').trim();
  const pathToUse = styleFile || getBundledStylePath(__dirname);
  log(`Loading style from: ${pathToUse}`);
  return loadStyle(pathToUse);
}

async function formatEditor(editor: vscode.TextEditor): Promise<void> {
  const doc = editor.document;
  const cfg = vscode.workspace.getConfiguration('sqlCodeFormatter');
  const dialect = cfg.get<string>('dialect', 'transactsql');
  const style = await getActiveStyle();

  const formatted = formatSql(doc.getText(), style, {
    dialect,
    editorTabSize: Number(editor.options.tabSize ?? vscode.workspace.getConfiguration('editor', doc.uri).get<number>('tabSize', 2)),
    insertSpaces: Boolean(editor.options.insertSpaces ?? vscode.workspace.getConfiguration('editor', doc.uri).get<boolean>('insertSpaces', true)),
    overrideTabSize: cfg.get<number | null>('overrideTabSize', null) ?? undefined,
    log
  });

  if (formatted === doc.getText()) {
    return;
  }

  const start = new vscode.Position(0, 0);
  const end = doc.lineAt(doc.lineCount - 1).range.end;

  await editor.edit(editBuilder => {
    editBuilder.replace(new vscode.Range(start, end), formatted);
  });
}

export function activate(context: vscode.ExtensionContext): void {
  output = vscode.window.createOutputChannel('SQL Code Formatter');
  context.subscriptions.push(output);

  const selector: vscode.DocumentSelector = [
    { language: 'sql' },
    { language: 'tsql' },
    { language: 'mysql' },
    { language: 'postgres' },
    { language: 'plsql' }
  ];

  const provider: vscode.DocumentFormattingEditProvider = {
    async provideDocumentFormattingEdits(document, options): Promise<vscode.TextEdit[]> {
      const cfg = vscode.workspace.getConfiguration('sqlCodeFormatter');
      const dialect = cfg.get<string>('dialect', 'transactsql');
      const style = await getActiveStyle();
      const formatted = formatSql(document.getText(), style, {
        dialect,
        editorTabSize: options.tabSize,
        insertSpaces: options.insertSpaces,
        overrideTabSize: cfg.get<number | null>('overrideTabSize', null) ?? undefined,
        log
      });

      const end = document.lineAt(document.lineCount - 1).range.end;
      return [vscode.TextEdit.replace(new vscode.Range(new vscode.Position(0, 0), end), formatted)];
    }
  };

  context.subscriptions.push(vscode.languages.registerDocumentFormattingEditProvider(selector, provider));

  context.subscriptions.push(vscode.commands.registerCommand('sqlCodeFormatter.formatDocument', async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      void vscode.window.showWarningMessage('No active editor found.');
      return;
    }
    await formatEditor(editor);
  }));

  context.subscriptions.push(vscode.commands.registerCommand('sqlCodeFormatter.reloadStyle', async () => {
    try {
      await getActiveStyle();
      void vscode.window.showInformationMessage('Style file reloaded successfully.');
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      void vscode.window.showErrorMessage(`Failed to load style file: ${message}`);
    }
  }));
}

export function deactivate(): void {
  // no-op
}
