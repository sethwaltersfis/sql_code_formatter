# SQL Code Formatter

This VS Code extension formats SQL using a **best-effort mapping** of a **JSON formatting style file**.

It ships with the bundled style copied from your uploaded settings file:

- **Style name:** default-style.json
- **Default tab width:** 2 spaces
- **Keyword/function/data type casing:** uppercase
- **Wrap width:** 300
- **Semicolon placement:** new line before semicolon
- **Leading commas:** enabled
- **Alias alignment:** enabled
- **Comment alignment:** enabled
- **Comparison operator alignment:** enabled

## Important note

This extension uses a hybrid approach:

1. It applies a base SQL layout using `sql-formatter`
2. It applies additional post-processing to approximate style-specific rules

That means this extension is practical and usable, but it is not a byte-for-byte clone of every formatter implementation.

## Included settings mapping

The bundled formatter currently supports these settings from your uploaded style file:

- `whitespace.numberOfSpacesInTabs`
- `whitespace.wrapLinesLongerThan`
- `whitespace.whiteSpaceBeforeSemiColon`
- `lists.placeCommasBeforeItems`
- `lists.alignAliases`
- `lists.alignComments`
- `casing.reservedKeywords`
- `casing.builtInFunctions`
- `casing.builtInDataTypes`
- `dml.addNewLineAfterDistinctAndTopClauses`
- `joinStatements.on.placeOnNewLine`
- `operators.andOr.alignment`
- `operators.comparison.align`

## Extension settings

- `sqlCodeFormatter.styleFile` - optional path to a JSON style file
- `sqlCodeFormatter.dialect` - SQL dialect passed to the formatter (`transactsql` by default)
- `sqlCodeFormatter.overrideTabSize` - optional tab-size override
- `sqlCodeFormatter.debugLogging` - write diagnostics to the output channel

## Commands

- **SQL Code Formatter: Format Active Document**
- **SQL Code Formatter: Reload Style File**
- **SQL Code Formatter: Format Selection**

## Set as your default SQL formatter

Add this to your VS Code `settings.json`:

```json
{
  "[sql]": {
    "editor.defaultFormatter": "sethwalters.sql-code-formatter",
    "editor.formatOnSave": true
  }
}
```

## New in v0.2.0

- Added **Format Selection** command: `SQL Code Formatter: Format Selection`
- Added support for VS Code's built-in **Format Selection** behavior by registering a **range formatting provider**
- Kept full-document formatting support intact