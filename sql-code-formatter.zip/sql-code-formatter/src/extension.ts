import * as vscode from 'vscode';
import { loadStyle, getBundledStylePath, type SqlStyle } from './styleFile';
import { formatSql } from './formatter';

let output: vscode.OutputChannel;

function log(message: string): void {
  const debug = vscode.workspace.getConfiguration('sqlCodeFormatter').get<boolean>('debugLogging', false);
  if (debug) {
    output.appendLine(message);
  }
}

async function getActiveStyle(): Promise<SqlStyle> {
  const cfg = vscode.workspace.getConfiguration('sqlCodeFormatter');
  const styleFile = cfg.get<string>('styleFile', '').trim();
  const pathToUse = styleFile || getBundledStylePath(__dirname);
  log(`Loading style from: ${pathToUse}`);
  return loadStyle(pathToUse);
}

function getRangeText(editor: vscode.TextEditor, range?: vscode.Range): string {
  if (range) {
    return editor.document.getText(range);
  }
  return editor.document.getText();
}

async function formatText(editor: vscode.TextEditor, range?: vscode.Range): Promise<void> {
  const doc = editor.document;
  const cfg = vscode.workspace.getConfiguration('sqlCodeFormatter');
  const dialect = cfg.get<string>('dialect', 'transactsql');
  const style = await getActiveStyle();

  const sourceText = getRangeText(editor, range);
  if (!sourceText.trim()) {
    return;
  }

  const formatted = formatSql(sourceText, style, {
    dialect,
    editorTabSize: Number(editor.options.tabSize ?? vscode.workspace.getConfiguration('editor', doc.uri).get<number>('tabSize', 2)),
    insertSpaces: Boolean(editor.options.insertSpaces ?? vscode.workspace.getConfiguration('editor', doc.uri).get<boolean>('insertSpaces', true)),
    overrideTabSize: cfg.get<number | null>('overrideTabSize', null) ?? undefined,
    log
  });

  const targetRange = range ?? new vscode.Range(new vscode.Position(0, 0), doc.lineAt(doc.lineCount - 1).range.end);

  if (formatted === doc.getText(targetRange)) {
    return;
  }

  await editor.edit(editBuilder => {
    editBuilder.replace(targetRange, formatted);
  });
}

async function createFormattedEdit(document: vscode.TextDocument, options: vscode.FormattingOptions, range?: vscode.Range): Promise<vscode.TextEdit[]> {
  const cfg = vscode.workspace.getConfiguration('sqlCodeFormatter');
  const dialect = cfg.get<string>('dialect', 'transactsql');
  const style = await getActiveStyle();
  const sourceText = range ? document.getText(range) : document.getText();

  if (!sourceText.trim()) {
    return [];
  }

  const formatted = formatSql(sourceText, style, {
    dialect,
    editorTabSize: options.tabSize,
    insertSpaces: options.insertSpaces,
    overrideTabSize: cfg.get<number | null>('overrideTabSize', null) ?? undefined,
    log
  });

  const targetRange = range ?? new vscode.Range(new vscode.Position(0, 0), document.lineAt(document.lineCount - 1).range.end);
  return [vscode.TextEdit.replace(targetRange, formatted)];
}

export function activate(context: vscode.ExtensionContext): void {
  output = vscode.window.createOutputChannel('SQL Code Formatter');
  context.subscriptions.push(output);

  const selector: vscode.DocumentSelector = [
    { language: 'sql' },
    { language: 'tsql' },
    { language: 'mysql' },
    { language: 'postgres' },
    { language: 'plsql' }
  ];

  const docProvider: vscode.DocumentFormattingEditProvider = {
    async provideDocumentFormattingEdits(document, options): Promise<vscode.TextEdit[]> {
      return createFormattedEdit(document, options);
    }
  };

  const rangeProvider: vscode.DocumentRangeFormattingEditProvider = {
    async provideDocumentRangeFormattingEdits(document, range, options): Promise<vscode.TextEdit[]> {
      return createFormattedEdit(document, options, range);
    }
  };

  context.subscriptions.push(vscode.languages.registerDocumentFormattingEditProvider(selector, docProvider));
  context.subscriptions.push(vscode.languages.registerDocumentRangeFormattingEditProvider(selector, rangeProvider));

  context.subscriptions.push(vscode.commands.registerCommand('sqlCodeFormatter.formatDocument', async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      void vscode.window.showWarningMessage('No active editor found.');
      return;
    }
    await formatText(editor);
  }));

  context.subscriptions.push(vscode.commands.registerCommand('sqlCodeFormatter.formatSelection', async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      void vscode.window.showWarningMessage('No active editor found.');
      return;
    }

    const selection = editor.selection;
    if (selection.isEmpty) {
      void vscode.window.showWarningMessage('No text is selected.');
      return;
    }

    await formatText(editor, new vscode.Range(selection.start, selection.end));
  }));

  context.subscriptions.push(vscode.commands.registerCommand('sqlCodeFormatter.reloadStyle', async () => {
    try {
      await getActiveStyle();
      void vscode.window.showInformationMessage('Style file reloaded successfully.');
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      void vscode.window.showErrorMessage(`Failed to load style file: ${message}`);
    }
  }));
}

export function deactivate(): void {
  // no-op
}
