import * as fs from 'fs';
import * as path from 'path';

export interface SqlStyle {
  metadata?: { id?: string; name?: string };
  whitespace?: {
    numberOfSpacesInTabs?: number;
    wrapLinesLongerThan?: number;
    whiteSpaceBeforeSemiColon?: 'newLineBefore' | 'sameLine';
  };
  lists?: {
    placeFirstItemOnNewLine?: 'always' | 'never';
    alignSubsequentItemsWithFirstItem?: boolean;
    alignItemsAcrossClauses?: boolean;
    alignAliases?: boolean;
    alignComments?: boolean;
    placeCommasBeforeItems?: boolean;
  };
  parentheses?: {
    collapseShortParenthesisContents?: boolean;
    collapseParenthesesShorterThan?: number;
  };
  casing?: {
    reservedKeywords?: 'uppercase' | 'lowercase' | 'preserve' | 'upper' | 'lower';
    builtInFunctions?: 'uppercase' | 'lowercase' | 'preserve' | 'upper' | 'lower';
    builtInDataTypes?: 'uppercase' | 'lowercase' | 'preserve' | 'upper' | 'lower';
    globalVariables?: 'uppercase' | 'lowercase' | 'preserve' | 'upper' | 'lower';
  };
  dml?: {
    addNewLineAfterDistinctAndTopClauses?: boolean;
    collapseStatementsShorterThan?: number;
  };
  joinStatements?: {
    on?: {
      placeOnNewLine?: boolean;
    };
  };
  operators?: {
    andOr?: {
      alignment?: 'rightAligned' | 'leftAligned';
    };
    comparison?: {
      align?: boolean;
    };
  };
}

export function loadStyle(stylePath: string): SqlStyle {
  const raw = fs.readFileSync(stylePath, 'utf8');
  return JSON.parse(raw) as SqlStyle;
}

export function getBundledStylePath(currentDir: string): string {
  return path.resolve(currentDir, '..', 'styles', 'default-style.json');
}
